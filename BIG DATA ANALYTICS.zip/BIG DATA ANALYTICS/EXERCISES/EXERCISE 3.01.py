#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt


# In[2]:


df = pd.read_csv('Documents/Datasets/austin_weather.csv')


# In[3]:


df.head()


# In[4]:


df = df.loc[:, ['Date', 'TempAvgF']]
df.head()


# In[5]:


df.loc[:, 'Year'] = df.loc[:, 'Date'].str.slice(0, 4).astype('int')
df.loc[:, 'Month'] = df.loc[:, 'Date'].str.slice(5, 7).astype('int')
df.loc[:, 'Day'] = df.loc[:, 'Date'].str.slice(8, 10).astype('int')
df = df.loc[df.index < 365]
print(df.head())
print(df.tail())


# In[6]:


window = 20
rolling = df.TempAvgF.rolling(window).mean()
print(rolling.head())
print(rolling.tail())


# In[7]:


fig = plt.figure(figsize=(10, 7))
ax = fig.add_axes([1, 1, 1, 1]);
#
# Raw data
#
ax.scatter(df.index, 
           df.TempAvgF, 
           label = 'Raw Data', c = 'k')
#
# Moving averages
#
ax.plot(rolling.index, 
        rolling, 
        c = 'r', 
        linestyle = '--', 
        label = f'{window} day moving average')
#
ax.set_title('Air Temperature Measurements',
             fontsize = 16)
ax.set_xlabel('Day', 
              fontsize = 14)
ax.set_ylabel('Temperature ($^\circ$F)', 
              fontsize = 14)
ax.set_xticks(range(df.index.min(), 
                    df.index.max(), 
                    30))
ax.tick_params(labelsize = 12)
ax.legend(fontsize = 12)
plt.show()


# In[ ]:




