#!/usr/bin/env python
# coding: utf-8

# In[28]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from sklearn.linear_model import SGDRegressor


# In[29]:


# load data and inspect
df = pd.read_csv('Documents/Datasets/austin_weather.csv')
df = df.loc[:, ['Date', 'TempAvgF']]
# add time-based columns
df.loc[:, 'Year'] = df.loc[:, 'Date'].str.slice(0, 4).astype('int')
df.loc[:, 'Month'] = df.loc[:, 'Date'].str.slice(5, 7).astype('int')
df.loc[:, 'Day'] = df.loc[:, 'Date'].str.slice(8, 10).astype('int')
# set a 20 day window then use that to smooth
# temperature in a new column
window = 20
df['20_d_mov_avg'] = df.TempAvgF.rolling(window).mean()
# now let's slice exactly one year on the
# calendar start and end dates
# we see from the previous output that
# 2014 is the first year with complete data,
# however it will still have NaN values for
# the moving average, so we'll use 2015
df_one_year = df.loc[df.Year == 2015, :].reset_index()
df_one_year['Day_of_Year'] = df_one_year.index + 1
print(df_one_year.head())
print(df_one_year.tail())


# In[31]:


#
# scale the data
#
X_min = df_one_year.Day_of_Year.min()
X_range = df_one_year.Day_of_Year.max() - df_one_year.Day_of_Year.min()
Y_min = df_one_year.TempAvgF.min()
Y_range = df_one_year.TempAvgF.max() - df_one_year.TempAvgF.min()
scale_X = (df_one_year.Day_of_Year - X_min) / X_range
#
train_X = scale_X.ravel()
train_Y = ((df_one_year.TempAvgF - Y_min) / Y_range).ravel()


# In[32]:


#
# create the model object
#
np.random.seed(42)
model = SGDRegressor(
    loss = 'squared_loss',
    max_iter = 100,
    learning_rate = 'constant',
    eta0 = 0.0005,
    tol = 0.00009,
    penalty = 'none')


# In[33]:


#
# fit the model
#
model.fit(train_X.reshape((-1, 1)), train_Y)


# In[34]:


Beta0 = (Y_min + Y_range * model.intercept_[0] - 
        Y_range * model.coef_[0] * X_min / X_range)
Beta1 = Y_range * model.coef_[0] / X_range
print(Beta0)
print(Beta1)


# In[35]:


#
# generate predictions
#
pred_X = df_one_year['Day_of_Year']
pred_Y = model.predict(train_X.reshape((-1, 1)))


# In[36]:


#
# calcualte the r squared value
#
r2 = r2_score(train_Y, pred_Y)
print('r squared = ', r2)


# In[37]:


#
# scale predictions back to real values
#
pred_Y = (pred_Y * Y_range) + Y_min


# In[38]:


fig = plt.figure(figsize = (10, 7))
ax = fig.add_axes([1, 1, 1, 1])
#
# Raw data
#
ax.scatter(df_one_year.Day_of_Year, 
           df_one_year.TempAvgF, 
           label = 'Raw Data', c = 'k')
#
# Moving averages
#
ax.plot(df_one_year.Day_of_Year,
        df_one_year['20_d_mov_avg'], 
        c = 'r', 
        linestyle = '--', 
        label = f'{window} day moving average')
#
# Regression predictions
#
ax.plot(pred_X, pred_Y,
        c = "blue",
        linestyle = '-.',
        linewidth = 4,
        label = 'linear fit (from SGD)')
#
# put the model on the plot
#
ax.text(1, 85,
        'Temp = ' + 
        str(round(Beta0, 2)) +
        ' + ' +
        str(round(Beta1, 4)) +
        ' * Day',
        fontsize = 16)
#
ax.set_title('Air Temperature Measurements',
             fontsize = 16)
ax.set_xlabel('Day', 
              fontsize = 14)
ax.set_ylabel('Temperature ($^\circ$F)', 
              fontsize = 14)
ax.set_xticks(range(df_one_year.Day_of_Year.min(), 
                    df_one_year.Day_of_Year.max(), 
                    30))
ax.tick_params(labelsize = 12)
ax.legend(fontsize = 12)
plt.show()


# In[ ]:




