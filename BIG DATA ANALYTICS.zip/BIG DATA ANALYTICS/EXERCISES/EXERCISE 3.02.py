#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


# In[6]:


# load data and inspect
df = pd.read_csv('Documents/Datasets/austin_weather.csv')
print(df.head())
print(df.tail())


# In[7]:


df = df.loc[:, ['Date', 'TempAvgF']]
df.head()


# In[8]:


# add some useful columns
df.loc[:, 'Year'] = df.loc[:, 'Date'].str.slice(0, 4).astype('int')
df.loc[:, 'Month'] = df.loc[:, 'Date'].str.slice(5, 7).astype('int')
df.loc[:, 'Day'] = df.loc[:, 'Date'].str.slice(8, 10).astype('int')
print(df.head())
print(df.tail())


# In[9]:


# set a 20 day window then use that to smooth
# temperature in a new column
window = 20
df['20_d_mov_avg'] = df.TempAvgF.rolling(window).mean()
print(df.head())
print(df.tail())


# In[10]:


# now let's slice exactly one year on the
# calendar start and end dates
# we see from the previous output that
# 2014 is the first year with complete data,
# however it will still have NaN values for
# the moving average, so we'll use 2015
df_one_year = df.loc[df.Year == 2015, :].reset_index()
df_one_year['Day_of_Year'] = df_one_year.index + 1
print(df_one_year.head())
print(df_one_year.tail())


# In[11]:


fig = plt.figure(figsize=(10, 7))
ax = fig.add_axes([1, 1, 1, 1]);
# Raw data
ax.scatter(df_one_year.Day_of_Year,
df_one_year.TempAvgF,
label = 'Raw Data', c = 'k')
# Moving averages
ax.plot(df_one_year.Day_of_Year,
df_one_year['20_d_mov_avg'],
c = 'r',
linestyle = '--',
label = f'{window} day moving average')
ax.set_title('Air Temperature Measurements',
fontsize = 16)
ax.set_xlabel('Day',
fontsize = 14)
ax.set_ylabel('Temperature ($^\circ$F)',
fontsize = 14)
ax.set_xticks(range(df_one_year.Day_of_Year.min(),
df_one_year.Day_of_Year.max(),
30))
ax.tick_params(labelsize = 12)
ax.legend(fontsize = 12)
plt.show()


# In[12]:


# fit a linear model
linear_model = LinearRegression(fit_intercept = True)
linear_model.fit(df_one_year['Day_of_Year'].values.reshape((-1, 1)),
df_one_year.TempAvgF)
print('model slope: ', linear_model.coef_)
print('model intercept: ', linear_model.intercept_)
print('model r squared: ',
linear_model.score(df_one_year['Day_of_Year'].values.reshape((-
1, 1)),
df_one_year.TempAvgF))


# In[13]:


# make predictions using the training data
y_pred = linear_model.predict(df_one_year['Day_of_Year'].values.
reshape((-1, 1)))
x_pred = df_one_year.Day_of_Year


# In[14]:


fig = plt.figure(figsize=(10, 7))
ax = fig.add_axes([1, 1, 1, 1]);
# Raw data
ax.scatter(df_one_year.Day_of_Year,
df_one_year.TempAvgF,
label = 'Raw Data', c = 'k')
# Moving averages
ax.plot(df_one_year.Day_of_Year,
df_one_year['20_d_mov_avg'],
c = 'r',
linestyle = '--',
label = f'{window} day moving average')
# linear model
ax.plot(x_pred, y_pred,
c = "blue",
linestyle = '-.',
label = 'linear model')
ax.set_title('Air Temperature Measurements',
fontsize = 16)
ax.set_xlabel('Day',
fontsize = 14)


# In[18]:


ax.set_ylabel('Temperature ($^\circ$F)',
fontsize = 14)
ax.set_xticks(range(df_one_year.Day_of_Year.min(),
df_one_year.Day_of_Year.max(),
30))
ax.tick_params(labelsize = 12)
ax.legend(fontsize = 12)
plt.show()

